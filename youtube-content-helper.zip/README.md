# 댓글에서 찾는 마케팅 힌트

유튜브 링크를 입력해 영상 정보·댓글 워드클라우드·마케팅 관점별 언급 댓글을 확인하는 Streamlit 앱입니다. 이전 부스 계산기처럼 GitHub 저장소와 Streamlit Community Cloud를 사용합니다.

## 파일과 역할

| 파일 | 역할 |
|---|---|
| app.py | 웹 화면, YouTube API 요청, 댓글 수집, 단어 집계, 분석 |
| requirements.txt | Python 라이브러리 설치 목록 |
| packages.txt | 한글 워드클라우드를 위한 나눔 폰트 설치 목록 |
| README.md | 설명서 (배포에 필수는 아님) |

세 필수 파일은 저장소 맨 위에 둡니다. 압축 파일을 그대로 올리지 마세요.

## 1. GitHub에 올리기

1. 압축 파일을 다운로드한 뒤 압축을 풉니다.
2. https://github.com 에 로그인합니다.
3. 오른쪽 위 + → New repository를 누릅니다.
4. Repository name에 `youtube-comment-insight`를 입력합니다.
5. Public과 Add README를 선택하고 Create repository를 누릅니다.
6. Add file → Upload files에서 `app.py`, `requirements.txt`, `packages.txt`를 드래그합니다.
7. Commit changes를 누릅니다. 이 세 파일이 README와 같은 층에 있는지 확인합니다.

## 2. YouTube API 키 발급

API 키는 앱이 유튜브 데이터를 요청할 때 쓰는 인증 키입니다.

1. https://console.cloud.google.com/ 에 Google 계정으로 로그인합니다.
2. 위쪽 프로젝트 선택 → 새 프로젝트 → 이름 `youtube-comment-insight` → 만들기를 누릅니다.
3. 만든 프로젝트를 선택합니다.
4. API 및 서비스 → 라이브러리 → `YouTube Data API v3` 검색 → 사용을 누릅니다.
5. API 및 서비스 → 사용자 인증 정보 → 사용자 인증 정보 만들기 → API 키를 선택합니다.
6. 키 편집 → API 제한사항에서 `YouTube Data API v3`만 허용하도록 설정합니다.
7. 발급받은 키를 보관합니다. GitHub 코드, README, 공개 화면에 넣지 마세요.

공개 영상·댓글 읽기에는 이 코드에서 API 키를 사용합니다. OAuth 클라이언트 ID는 만들 필요가 없습니다. 이 앱은 서버에서 요청하므로 브라우저 HTTP referrer 제한은 맞지 않습니다. 학교 관리 계정에서 프로젝트 생성이 제한되면 계정 관리자 설정을 확인해야 합니다.

## 3. Streamlit 배포

1. https://share.streamlit.io/ 에서 기존 GitHub 계정으로 로그인합니다.
2. Create app → GitHub에서 배포하는 선택지(예: Yup, I have an app)로 이동합니다.
3. 다음과 같이 입력합니다.
   - Repository: `본인아이디/youtube-comment-insight`
   - Branch: `main`
   - Main file path: `app.py`
4. Advanced settings → Secrets에 아래 한 줄을 넣습니다. 따옴표는 남기고 실제 키로 바꿉니다.

```toml
YOUTUBE_API_KEY = "발급받은_API_키"
```

5. Save → Deploy를 누릅니다.
6. 설치가 끝나고 앱 주소가 나오면 접속합니다.

Secrets에 입력하는 한 줄은 GitHub에 올리지 않습니다. 이미 배포했다면 Streamlit 앱 Settings → Secrets에서 설정할 수 있습니다.

## 4. 사용하기

1. 공개된 브랜드 광고, 제품 리뷰, 카페 소개 등 댓글이 있는 유튜브 영상의 공유 링크를 복사합니다.
2. 앱에 붙여넣고 수집 개수 200개, 최신순으로 시작합니다.
3. 영상과 댓글 분석하기를 누릅니다.
4. 영상 정보, 수집 개수, 워드클라우드, 단어 빈도표를 확인합니다.
5. 자주 나오지만 분석에 필요 없는 단어는 제외 단어에 추가합니다.
6. 가격·가성비, 제품·품질, 구매·이용, 서비스·배송, 정보 요청 항목의 검색 단어를 영상에 맞게 수정합니다.
7. 각 항목을 펼쳐 실제 댓글 원문을 확인합니다.
8. 관찰, 원문 근거, 마케팅·운영 개선 가설, 추가 확인할 점을 메모합니다.
9. 워드클라우드 PNG, 수집 댓글 CSV, 분석 메모를 다운로드합니다.

## 5. 해석 방법

- 워드클라우드: 수집 댓글에서 2글자 이상 한글·영문 문자열이 나온 횟수입니다. 명사 추출·문맥 분석·AI 감성 분석이 아닙니다. ‘가격’과 ‘가격이’는 다르게 셉니다.
- 마케팅 항목: 지정한 단어 중 하나라도 포함된 댓글의 수입니다. 한 댓글이 여러 항목에 포함될 수 있습니다. 예를 들어 ‘맛’은 ‘맛있다’와 ‘맛없다’에 모두 해당합니다.
- 가격 언급이 많다는 것은 가격이 비싸다는 뜻이 아닙니다. 구매 관련 단어가 많다는 것은 실제 구매나 구매 의도가 많다는 뜻이 아닙니다.
- 최신순 또는 관련성순 최상위 댓글만 수집합니다. 답글과 비공개·삭제된 댓글은 포함하지 않습니다.
- API의 전체 댓글 수와 수집한 최상위 댓글 수는 다를 수 있습니다. 설정한 수는 최대 개수이므로 실제 수집량은 적을 수 있습니다.
- 댓글 작성자는 전체 소비자를 대표하지 않습니다. 매출·구매전환율·연령·성별·광고 효과는 이 데이터만으로 알 수 없습니다.
- 동일 요청 결과는 최대 10분 캐시합니다. API 사용 한도는 Google Cloud에서 확인합니다.
- 댓글 작성자 이름은 수집하지 않습니다. 공개 댓글에도 개인 정보가 들어 있을 수 있으므로 제출·공유 시 원문을 확인하세요.

## 6. 오류 해결

| 현상 | 확인할 내용 |
|---|---|
| API 키 설정 안내 | Streamlit Secrets의 `YOUTUBE_API_KEY` 철자와 따옴표 확인 |
| 데이터 요청 거절 | API를 사용 설정한 프로젝트에서 발급한 키인지, 키 제한이 맞는지 확인 |
| 댓글 사용 중지 | 댓글이 열려 있는 다른 영상으로 시도 |
| 댓글 0개 | 댓글이 실제로 있는 공개 영상인지 확인 |
| API 한도 초과 | Google Cloud 할당량을 확인하고 나중에 다시 시도 |
| 한글 폰트 없음 | `packages.txt`가 저장소 맨 위에 있고 내용이 `fonts-nanum`인지 확인 후 Streamlit Reboot |
| 라이브러리 오류 | `requirements.txt`가 저장소 맨 위에 있는지 확인 |

## 탐구 보고서 연결

주제: 유튜브 댓글의 반복 단어와 소비자 관심 요소 분석을 활용한 마케팅 의사결정 지원 웹 서비스 개발

연구 흐름: 영상 선정 이유 → 표본 수집 조건 → 단어·관점별 집계 → 댓글 원문 검토 → 마케팅·운영 개선 가설 → 데이터의 한계

예시 해석: 위치 문의 댓글이 반복되어, 설명란에 지도 링크를 넣으면 정보 탐색을 도울 수 있다는 가설을 세운다. 실제 방문 증가 여부는 별도 측정이 필요하다.

## 로컬 실행 (선택)

GitHub → Streamlit 배포만 따라 한다면 PC에 Python을 설치할 필요가 없습니다.
로컬 실행 시에는 라이브러리를 설치하고 `.streamlit/secrets.toml`에 키를 넣습니다. 이 파일은 GitHub에 올리지 않습니다. 한글 폰트 `NanumGothic.ttf`를 app.py 옆에 준비해야 합니다.

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 공식 문서

- https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy
- https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/secrets-management
- https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies
- https://developers.google.com/youtube/v3/getting-started
- https://developers.google.com/youtube/v3/docs/commentThreads/list
- https://developers.google.com/youtube/v3/docs/videos
- https://amueller.github.io/word_cloud/generated/wordcloud.WordCloud.html
